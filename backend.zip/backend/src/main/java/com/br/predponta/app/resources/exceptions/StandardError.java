package com.br.predponta.app.resources.exceptions;

import java.io.Serializable;
import java.time.Instant;

public class StandardError implements Serializable{
	private static final long serialVersionUID = 1L;

	
	private Instant timestmap;
	private Integer status;
	private String error;
	private String message;
	private String path;
		
	public  StandardError() {
			
	}

	public Instant getTimestmap() {
		return timestmap;
	}

	public void setTimestmap(Instant timestmap) {
		this.timestmap = timestmap;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	public String getPath() {
		return path;
	}


	public void setPath(String path) {
		this.path = path;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}
	
}
