package com.br.predponta.app.config;

import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
//import org.springframework.web.bind.annotation.RestController;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.service.VendorExtension;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfig {
	
	@Bean
    public Docket predpontaApi() {
        return new Docket(DocumentationType.SWAGGER_2)
               .select()
                .apis(RequestHandlerSelectors.basePackage("com.br.predponta.app"))
                
                .paths(PathSelectors.any())

                .build()
                .apiInfo(metaInfo());
      
//   @Configuration
//   @EnableSwagger2
//        public class SwaggerConfig {
	   
//       	@Bean
//        	public Docket predpontaApi() {
//        		return new Docket(DocumentationType.SWAGGER_2).select()
 //       				.apis(RequestHandlerSelectors.withClassAnnotation(RestController.class)).paths(PathSelectors.any())
 //       				.build();
        		
        	}  
            

    private ApiInfo metaInfo() {

        @SuppressWarnings("rawtypes")
		ApiInfo apiInfo = new ApiInfo(
                "Predponta API REST",
                "API REST PredPonta.",
                "1.0",
                "Terms of Service",
                new Contact("Eagles Automation", "https://www.linkedin.com/in/dennis-ribeiro-24956868",
                        "dennis_fdr@hotmail.com"),
                "Apache License Version 2.0",
                "https://www.apache.org/licesen.html", new ArrayList<VendorExtension>()
        );

        return apiInfo;
    }

}
